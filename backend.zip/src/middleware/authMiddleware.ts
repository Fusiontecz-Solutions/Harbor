import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import prisma from '../config/prismaClient';

// Extend Express Request type to include user
declare global {
    namespace Express {
        interface Request {
            user?: {
                id: string;
                name: string;
                email: string;
                role: string;
                publicApprovalActor?: 'CLIENT' | 'ISO';
            };
        }
    }
}

/**
 * Sentinel identity used when a request was authenticated via the trusted
 * Super Admin proxy path (signed headers) rather than a tenant JWT.
 *
 * The tenant DB knows nothing about Super Admin users — they live in a
 * separate centralized backend — so we never attempt to look them up here.
 * We just construct a synthetic principal with SUPER_ADMIN role so existing
 * role gates (requireRoles / requireAdmin) keep working.
 */
const SUPER_ADMIN_PROXY_SENTINEL_ID = '00000000-0000-0000-0000-000000000000';

const buildSuperAdminProxyUser = (req: Request) => {
    const ctx = req.superAdminContext || {};
    return {
        id: ctx.actorId || SUPER_ADMIN_PROXY_SENTINEL_ID,
        name: ctx.actorName || 'Super Admin (proxy)',
        email: ctx.actorEmail || 'super-admin@proxy.internal',
        role: 'SUPER_ADMIN',
    };
};

/**
 * User id safe for tenant DB foreign keys (e.g. Application.createdById).
 * Super Admin proxy principals are synthetic and have no row in User — return null.
 */
export function resolveTenantUserId(req: Request): string | null {
    if (req.isSuperAdminProxy) return null;
    return req.user?.id ?? null;
}

export type ApplicationAttributionContext = {
    createdById: string | null;
    salesRepresentativeId: string;
};

export const APPLICATION_USER_ATTRIBUTION_ERROR =
    'Could not attribute this action to a tenant user. Ensure the application has a valid creator or sales representative.';

const resolveApplicationAttributedUserIdFromActorId = async (
    actorUserId: string | null | undefined,
    application: ApplicationAttributionContext,
): Promise<string | null> => {
    if (actorUserId) {
        const actor = await prisma.user.findUnique({
            where: { id: actorUserId },
            select: { id: true },
        });
        if (actor) return actor.id;
    }

    const fallbackIds = [
        application.createdById,
        application.salesRepresentativeId,
    ].filter((id): id is string => typeof id === 'string' && id.length > 0);

    for (const candidateId of fallbackIds) {
        const user = await prisma.user.findUnique({
            where: { id: candidateId },
            select: { id: true },
        });
        if (user) return user.id;
    }

    return null;
};

/**
 * Resolves a tenant User.id for required application FKs (BankDetail, BankAnalysis, Note, etc.).
 * Regular users are attributed to themselves when their id exists in User.
 * Super Admin proxy calls have no tenant User row — fall back to the application's
 * creator or sales representative (same pattern as contract creation).
 */
export async function resolveApplicationAttributedUserId(
    req: Request,
    application: ApplicationAttributionContext,
): Promise<string | null> {
    return resolveApplicationAttributedUserIdFromActorId(resolveTenantUserId(req), application);
}

/** Same attribution rules as above, but accepts a raw actor id (e.g. from AuthenticatedUser). */
export async function resolveApplicationAttributedUserIdForActor(
    actorUserId: string | null | undefined,
    application: ApplicationAttributionContext,
): Promise<string | null> {
    return resolveApplicationAttributedUserIdFromActorId(actorUserId, application);
}

/** @deprecated Use resolveApplicationAttributedUserId */
export const resolveBankDetailCreatedById = resolveApplicationAttributedUserId;

/**
 * Tenant user id when it exists in User; otherwise null (safe for optional createdById FK).
 * Super Admin proxy principals never write a synthetic id into the database.
 */
export async function resolveOptionalTenantUserId(req: Request): Promise<string | null> {
    const tenantUserId = resolveTenantUserId(req);
    if (!tenantUserId) return null;
    const actor = await prisma.user.findUnique({
        where: { id: tenantUserId },
        select: { id: true },
    });
    return actor?.id ?? null;
}

export type AuditLogUserResolveOptions = {
    user?: { id?: string; role?: string } | null;
    applicationId?: string | null;
};

/**
 * Resolves a tenant User.id safe for optional audit FKs
 * (ApplicationActivityLog.userId, OutboundCommunication.createdById).
 *
 * - Regular JWT users: their row in User when it exists.
 * - Super Admin proxy: no synthetic id; falls back to the application's
 *   creator or sales representative when applicationId is known.
 * - Invalid / missing user with applicationId: same application fallback.
 */
export async function resolveAuditLogUserId(
    req: Request | null | undefined,
    options?: AuditLogUserResolveOptions,
): Promise<string | null> {
    const applicationId =
        options?.applicationId && String(options.applicationId).trim().length > 0
            ? String(options.applicationId).trim()
            : null;

    if (req) {
        const fromReq = await resolveOptionalTenantUserId(req);
        if (fromReq) return fromReq;

        if (applicationId) {
            const app = await prisma.application.findUnique({
                where: { id: applicationId },
                select: { createdById: true, salesRepresentativeId: true },
            });
            if (app) {
                return resolveApplicationAttributedUserId(req, app);
            }
        }
        return null;
    }

    const userId = options?.user?.id;
    if (userId) {
        const actor = await prisma.user.findUnique({
            where: { id: userId },
            select: { id: true },
        });
        if (actor) return actor.id;
    }

    if (applicationId) {
        const app = await prisma.application.findUnique({
            where: { id: applicationId },
            select: { createdById: true, salesRepresentativeId: true },
        });
        if (app) {
            const fallbackIds = [app.createdById, app.salesRepresentativeId].filter(
                (id): id is string => typeof id === 'string' && id.length > 0,
            );
            for (const candidateId of fallbackIds) {
                const row = await prisma.user.findUnique({
                    where: { id: candidateId },
                    select: { id: true },
                });
                if (row) return row.id;
            }
        }
    }

    return null;
}

export const authenticateToken = async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<Response | void> => {
    try {
        // Trusted internal call from the centralized Super Admin backend.
        // `verifySuperAdminProxy` has already validated the shared secret
        // (constant-time compared against SUPER_ADMIN_SECRET) before this
        // middleware runs, so we MUST NOT try to validate a tenant JWT here.
        if (req.isSuperAdminProxy) {
            req.user = buildSuperAdminProxyUser(req);
            return next();
        }

        // Get token from Authorization header or cookies
        const authHeader = req.headers.authorization;
        const token = authHeader?.split(' ')[1] || req.cookies?.token;

        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Authentication token required',
            });
        }

        // Verify JWT token
        const decoded = jwt.verify(token, process.env.JWT_SECRET!) as {
            id: string;
            name: string;
            email: string;
            role: string;
            publicApprovalActor?: 'CLIENT' | 'ISO';
        };

        // Check if token exists in AccessToken table and is not expired
        const accessToken = await prisma.accessToken.findFirst({
            where: {
                token,
                userId: decoded.id,
            },
        });

        if (!accessToken) {
            return res.status(401).json({
                success: false,
                message: 'Invalid or expired token',
            });
        }

        // Check if token is expired
        if (accessToken.expiresAt < new Date()) {
            // Optionally delete expired token
            await prisma.accessToken.deleteMany({ where: { token } });
            return res.status(401).json({
                success: false,
                message: 'Token has expired',
            });
        }

        // Set user info in request object
        req.user = {
            id: decoded.id,
            name: decoded.name,
            email: decoded.email,
            role: decoded.role,
            publicApprovalActor: decoded.publicApprovalActor,
        };

        next();
    } catch (error: any) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                success: false,
                message: 'Invalid token',
            });
        }
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Token has expired',
            });
        }
        console.error('Authentication error:', error);
        res.status(500).json({
            success: false,
            message: 'Authentication error',
        });
        return;
    }
};

