declare module 'ws';

