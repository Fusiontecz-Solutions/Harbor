import { v2 as cloudinary } from 'cloudinary';
import dotenv from 'dotenv';

dotenv.config();

// Connect to Cloudinary
export const cloudinaryConnect = () => {
    try {
        cloudinary.config({
            cloud_name: process.env.CLOUD_NAME,
            api_key: process.env.API_KEY,
            api_secret: process.env.API_SECRET,
        });
        console.log('Cloudinary connected successfully');
    } catch (error) {
        console.error('Error occurred while connecting to Cloudinary:', error);
    }
};

export { cloudinary };
export default cloudinaryConnect;
