import { formatUSD } from "@/utils/formatCurrency";

/** Primary signer role when the template defines multiple roles but only one should receive the envelope. */
export const DOCUSIGN_PRIMARY_SIGNER_ROLE = String(
    (typeof import.meta !== "undefined" &&
        (import.meta.env?.VITE_DOCUSIGN_SIGNER_ROLE ||
            import.meta.env?.VITE_DOCUSIGN_PRIMARY_SIGNER_ROLE ||
            import.meta.env?.VITE_DOCUSIGN_DEFAULT_ROLE_NAME ||
            import.meta.env?.VITE_DOCUSIGN_DEFAULT_SIGNER_ROLE)) ||
        "Signer",
).trim();

/** Default signer role when template recipients are unavailable (must match DocuSign template). */
export const DOCUSIGN_DEFAULT_SIGNER_ROLE = DOCUSIGN_PRIMARY_SIGNER_ROLE;

/** Public HTTPS URL DocuSign redirects to after Send (required for localhost dev). */
export const DOCUSIGN_SENDER_RETURN_URL = String(
    (typeof import.meta !== "undefined" &&
        import.meta.env?.VITE_DOCUSIGN_SENDER_RETURN_URL) ||
        "",
).trim();

/** DocuSign template GUID — must exist in the connected DocuSign account (demo vs prod). */
export const DEFAULT_DOCUSIGN_TEMPLATE_ID = String(
    (typeof import.meta !== "undefined" &&
        (import.meta.env?.VITE_DOCUSIGN_TEMPLATE_ID ||
            import.meta.env?.VITE_BOLDSIGN_TEMPLATE_ID)) ||
        "",
).trim();

/** Lender prefix for contract / ACH envelope email subjects and PDF names. */
export const CONTRACT_ENVELOPE_LENDER_NAME = String(
    (typeof import.meta !== "undefined" &&
        import.meta.env?.VITE_DOCUSIGN_EMAIL_LENDER_NAME) ||
        "KATAN CAPITAL",
).trim();

/** @deprecated Use CONTRACT_ENVELOPE_LENDER_NAME */
export const DOCUSIGN_EMAIL_LENDER_NAME = CONTRACT_ENVELOPE_LENDER_NAME;

/** Contract envelope email subject: KATAN CAPITAL : BusinessName - $Offer Amount */
export function buildContractEnvelopeEmailSubject(
    businessName: string,
    offerAmount?: number | string | null,
): string {
    const business = String(businessName || "").trim() || "Business";
    const amount = formatUSD(offerAmount, { fallback: "$0.00" });
    return `${CONTRACT_ENVELOPE_LENDER_NAME} : ${business} - ${amount}`;
}

/** ACH-only envelope email subject and PDF name: ACH FORM: BusinessName */
export function buildAchFormEnvelopeEmailSubject(businessName: string): string {
    const business = String(businessName || "").trim() || "Business";
    return `ACH FORM: ${business}`;
}

/** @deprecated Use buildContractEnvelopeEmailSubject */
export function buildDocuSignEnvelopeEmailSubject(
    businessName: string,
    offerAmount?: number | string | null,
): string {
    return buildContractEnvelopeEmailSubject(businessName, offerAmount);
}
