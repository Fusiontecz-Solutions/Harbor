export {
  BUILTIN_FE_TEMPLATE_ID_PREFIX,
  BUILTIN_FE_TEMPLATES,
  getBuiltinReactTemplateDefinition,
  isBuiltinFeTemplate,
  mergeBuiltinFeTemplates,
  previewValuesForBuiltinDefinition,
  renderBuiltinReactTemplateHtml,
} from "./registry";

export type {
  TemplateCategory,
  TemplateComponentProps,
  TemplateDefinition,
  TemplateValues,
  TemplateVariable,
} from "./types";
export { TEMPLATE_CATEGORY_LABELS, pick } from "./types";
export {
  default as ApplicationApprovalEmail,
  APPLICATION_APPROVAL_EMAIL_VARIABLES,
} from "./ApplicationApprovalEmail";
export { renderApplicationApprovalEmailHtml } from "./applicationApprovalEmailHtml";
export {
  default as ApplicationRejectionEmail,
  APPLICATION_REJECTION_EMAIL_VARIABLES,
} from "./ApplicationRejectionEmail";
export { renderApplicationRejectionEmailHtml } from "./applicationRejectionEmailHtml";
export { renderDocumentRequestEmailHtml } from "./documentRequestEmailHtml";
// export { renderOfferUpdatedEmailHtml } from "./offerUpdatedEmailHtml";
// export {
//   APPLICATION_APPROVAL_EMAIL_SUBJECT,
//   OFFER_UPDATED_EMAIL_SUBJECT,
//   resolveApplicationApprovalEmailFields,
// } from "./applicationApprovalEmailShared";
export {
  APPLICATION_REJECTION_EMAIL_SUBJECT,
  resolveApplicationRejectionEmailFields,
} from "./applicationRejectionEmailShared";
export {
  DOCUMENT_REQUEST_UPLOAD_URL_PLACEHOLDER,
  documentRequestEmailSubject,
  resolveDocumentRequestEmailFields,
} from "./documentRequestEmailShared";
